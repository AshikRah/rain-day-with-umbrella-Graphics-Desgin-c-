#include<iostream>
#include<graphics.h>
#include<stdlib.h>
#include<dos.h>


#define ScreenWidth getmaxx()
#define ScreenHeight getmaxy()
#define GroundY ScreenHeight*0.75


void Rain(int x)
{
int i,rx,ry;
for(i=0;i<600;i++)
{
 setcolor(RED);
 setfillstyle(SOLID_FILL,RED);
 rx=rand() % ScreenWidth;
 ry=rand() % ScreenHeight;
 if(ry<GroundY-4)
 {
  if(ry<GroundY-120 || (ry>GroundY-120 && (rx<x-20 || rx>x+60)))
  line(rx,ry,rx+0.5,ry+4);
 }
}
}

int main()
{
    int a=DETECT;
    int b,i,j,x;
    initgraph(&a,&b,"C:\\TC\\BGI");

    for(i=0;i<=600;i++)
    {
        j=(j+2)%60;

        //umber....
        setcolor(YELLOW);
        setfillstyle(SOLID_FILL,YELLOW);
        arc(120+i,120,0,180,60);
        setcolor(BROWN);
        setfillstyle(SOLID_FILL,BROWN);
        line(60+i,120,180+i,120);
        setcolor(GREEN);
        setfillstyle(SOLID_FILL,GREEN);
        line(120+i,120,120+i,270);

        setcolor(YELLOW);
        setfillstyle(SOLID_FILL,YELLOW);
        line(70+i,90,70+i,120);
        line(80+i,80,80+i,120);
        line(90+i,70,90+i,120);
        line(100+i,65,100+i,120);
        line(110+i,60,110+i,120);
        line(120+i,55,120+i,120);
        line(130+i,60,130+i,120);
        line(140+i,65,140+i,120);
        line(150+i,70,150+i,120);
        line(160+i,80,160+i,120);
        line(170+i,90,170+i,120);

        setcolor(WHITE);
        setfillstyle(SOLID_FILL,WHITE);
        //head........
        circle(100+i,200,30);
        circle(85+i,200,7);
        circle(115+i,200,7);
        line(100+i,230,100+i,300);

        //hand.......
        line(100+i,230,(70+i)+j,270);
        line(100+i,230,120+i,270);
        //leg....
        line(100+i,300,(70+i)+j,350);
        line(100+i,300,(130+i)-j,350);

        line(0,GroundY,ScreenWidth,GroundY);
        Rain(x);


        delay(20);
        cleardevice();

         x=(x+1)%ScreenWidth;

        setcolor(BLUE);
        setfillstyle(SOLID_FILL,BLUE);
        line(0,350,650,350);


    }


    getch();
    closegraph();
}
